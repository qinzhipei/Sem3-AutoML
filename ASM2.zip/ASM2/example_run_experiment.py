import argparse
import ConfigSpace
import logging
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from lccv import LCCV
from surrogate_model import SurrogateModel, Pipeline
from vertical_model_evaluator import VerticalModelEvaluator

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config_space_file', type=str, default='lcdb_config_space_knn.json')
    parser.add_argument('--configurations_performance_file', type=str, default='config_performances_dataset-6.csv')
    # parser.add_argument('--configurations_performance_file', type=str, default='config_performances_dataset-11.csv')
    # parser.add_argument('--configurations_performance_file', type=str, default='config_performances_dataset-1457.csv')
    # parser.add_argument('--configurations_performance_file', type=str, default='lcdb_configs.csv')
    # max_anchor_size: connected to the configurations_performance_file. The max value upon which anchors are sampled
    parser.add_argument('--minimal_anchor', type=int, default=256)
    parser.add_argument('--max_anchor_size', type=int, default=16000)
    parser.add_argument('--num_iterations', type=int, default=50)
    return parser.parse_args()

def run(args):
    config_space = ConfigSpace.ConfigurationSpace.from_json(args.config_space_file)
    df = pd.read_csv(args.configurations_performance_file)
    surrogate_model = SurrogateModel(config_space)
    surrogate_model.fit(df)
    lccv = LCCV(surrogate_model, args.minimal_anchor, args.max_anchor_size)
    best_so_far = None
    for idx in range(args.num_iterations):
        theta_new = dict(config_space.sample_configuration())
        result = lccv.evaluate_model(best_so_far, theta_new)
        final_result = result[-1][1]
        if best_so_far is None or final_result < best_so_far:
            best_so_far = final_result
        x_values = [i[0] for i in result]
        y_values = [i[1] for i in result]
        plt.plot(x_values, y_values, "-o")
    plt.show()

def run_ipl(args):
    config_space = ConfigSpace.ConfigurationSpace.from_json(args.config_space_file)
    df = pd.read_csv(args.configurations_performance_file)
    surrogate_model = SurrogateModel(config_space)
    surrogate_model.fit(df)
    minimal_anchor = args.minimal_anchor
    final_anchor = args.max_anchor_size
    anchor_sizes = [16, 32, 64, 128, 256]

    evaluator = VerticalModelEvaluator(surrogate_model, minimal_anchor, final_anchor)
    surg_pred_values = [[] for i in range(5)]
    mean_curve_values = [[] for i in range(5)]
    best_so_far = None
    for idx in range(args.num_iterations):
        theta_new = dict(config_space.sample_configuration())
        result = evaluator.evaluate_model(best_so_far, theta_new)
        final_result = result[-1][1]
        surrogate_model_pred, mean_value_curve = evaluator.evaluate_model(best_so_far, theta_new)
        for i, (surg_pred, ipl_value) in enumerate(zip(surrogate_model_pred,mean_value_curve)):
            surg_pred_values[i].append(surg_pred)
            mean_curve_values[i].append(ipl_value)

    # plt.figure(figsize=(12,8))
    colors = plt.cm.tab10(range(5))
    for i, (surg_pred_values, mean_values) in enumerate(zip(surg_pred_values, mean_curve_values)):
        plt.plot(range(len(surg_pred_values)),surg_pred_values,label=f"Learning Curve = {anchor_sizes[i]}",marker='o',markersize=3,color=colors[i])    
    plt.plot(range(len(mean_values)),mean_values,label=f"IPL Extrapolation",marker="s",markersize=3,linestyle="--",color='blue')
    plt.legend()
    plt.xlabel("Epochs")
    plt.ylabel("Predicted Performance")
    plt.title("Performance of Model against IPL Extrapolation on Config-Dataset-6")
    # plt.title("Performance of Model against IPL Extrapolation on Config-Dataset-11")
    # plt.title("Performance of Model against IPL Extrapolation on Config-Dataset-1457")
    # plt.title("Performance of Model against IPL Extrapolation on LCDB")
    plt.show()

def metrics(args):
    config_space = ConfigSpace.ConfigurationSpace.from_json(args.config_space_file)
    df = pd.read_csv(args.configurations_performance_file)
    surrogate_model = SurrogateModel(config_space)
    surrogate_model.fit(df)
    spearman_correlation, p_value, mean_score, r2_score = surrogate_model.metrics()
    print('Spearman Correlation is {}'.format(np.round(spearman_correlation['Value'].mean(),5)))
    print('p-value is {}'.format(np.round(p_value['Value'].mean(),5)))
    print('MSE score of dataset is {}'.format(np.round(mean_score,5)))
    print('r2 Score is {}'.format(np.round(r2_score,5)))

if __name__ == '__main__':
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    #run(parse_args())
    run_ipl(parse_args())
    # metrics(parse_args())