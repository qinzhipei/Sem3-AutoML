
import typing

class LCCV:
    def __init__(self, anchors, max_anchor):
        """
        Initialize the LCCV class.
        :param anchors: List of available anchor sizes (sorted in ascending order).
        :param max_anchor: Maximum anchor size for extrapolation target.
        """
        self.anchors = anchors
        self.max_anchor = max_anchor

    @staticmethod
    def optimistic_extrapolation(
        previous_anchor: int,
        previous_performance: float,
        current_anchor: int,
        current_performance: float,
        target_anchor: int
    ) -> float:
        """
        Perform optimistic extrapolation based on anchor performance values.
        :param previous_anchor: Size of the previous anchor.
        :param previous_performance: Performance value for the previous anchor.
        :param current_anchor: Size of the current anchor.
        :param current_performance: Performance value for the current anchor.
        :param target_anchor: Size of the target anchor.
        :return: Extrapolated performance value.
        """
        slope = (previous_performance - current_performance) / (previous_anchor - current_anchor)
        extrapolated_score = current_performance - (target_anchor - current_anchor) * slope
        return extrapolated_score

    def evaluate_model(
        self,
        learner_inst,
        evaluator,
        best_so_far: typing.Optional[float],
        configuration: typing.Dict,
        r: float = 0.8
    ) -> typing.List[typing.Tuple[int, float]]:
        """
        Evaluate the model in segments and perform extrapolation at each anchor.
        :param learner_inst: Learner instance.
        :param evaluator: Evaluator function.
        :param best_so_far: The best known performance so far.
        :param configuration: Model configuration as a dictionary.
        :param r: Threshold for early stopping.
        :return: Evaluation results for each anchor [(anchor_size, performance)].
        """
        evaluations = []
        for i, anchor in enumerate(self.anchors):
            # Call the evaluator to assess the performance at the current anchor.
            result = evaluator(
                learner_inst=learner_inst,
                anchor=anchor,
                timeout=None,
                base_scoring=("dummy", lambda l, x, y: None),
                additional_scorings=None,
            )
            current_score = result["score_test_dummy"]
            evaluations.append((anchor, current_score))

            # Extrapolation logic: Start once there are at least two points.
            if i > 0:
                prev_anchor, prev_score = evaluations[-2]
                extrapolated_score = self.optimistic_extrapolation(
                    previous_anchor=prev_anchor,
                    previous_performance=prev_score,
                    current_anchor=anchor,
                    current_performance=current_score,
                    target_anchor=self.max_anchor
                )
                # Early stopping logic.
                if best_so_far is not None and extrapolated_score <= best_so_far * r:
                    print(f"Early stopping at anchor {anchor} with extrapolated_score={extrapolated_score}")
                    break

        return evaluations




