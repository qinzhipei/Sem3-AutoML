# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 05:38:51 2024

@author: admin
"""

import matplotlib.pyplot as plt
import warnings

from surrogate_model import SurrogateModel
from collections import defaultdict
import numpy as np
from ConfigSpace import ConfigurationSpace
from ConfigSpace.hyperparameters import CategoricalHyperparameter, UniformIntegerHyperparameter
from lccv_module import LCCV
import pandas as pd
import optuna
from sklearn.neighbors import KNeighborsClassifier

warnings.filterwarnings("ignore")

data = pd.read_csv(r"config_performances_dataset-6.csv")
data = data[['metric', 'n_neighbors', 'weights', 'p', 'anchor_size', 'score']]

# All parameter combinations
valid_combinations = data[['metric', 'n_neighbors', 'weights', 'p', 'anchor_size']].drop_duplicates()
valid_combinations = [tuple(row) for row in valid_combinations.to_numpy()]

max_anchor = 16000  
'''Surrogate Model'''
# Define the parameter space
config_space = ConfigurationSpace()
config_space.add_hyperparameters([
    CategoricalHyperparameter("metric", ["cosine", "minkowski", "nan_euclidean"]),
    UniformIntegerHyperparameter("n_neighbors", lower=1, upper=100),
    CategoricalHyperparameter("weights", ["uniform", "distance"]),
    UniformIntegerHyperparameter("p", lower=1, upper=10),
    UniformIntegerHyperparameter("anchor_size", lower=16, upper=max_anchor),
])

# Initialize and fit the surrogate model
Model = SurrogateModel(config_space)
Model.fit(data)

anchors = sorted(data['anchor_size'].unique())
lccv_instance = LCCV(anchors=anchors, max_anchor=max_anchor)

# Custom evaluator
def custom_evaluator(params):
    metric, n_neighbors, weights, p, anchor_size = params
    # Find matching rows in the original dataset
    row = data[
        (data['metric'] == metric) &
        (data['n_neighbors'] == n_neighbors) &
        (data['weights'] == weights) &
        (data['p'] == p) &
        (data['anchor_size'] == anchor_size)
    ]

    if row.empty:
        return None

    score = row.iloc[0]['score']
    return {
        "fittime": 0.1,  
        "score_train_dummy": score - 0.01,  
        "score_test_dummy": score,         
        "scoretime_train_dummy": 0.0,      
        "scoretime_test_dummy": 0.0        
    } # Returns a simulated result dictionary with training time and performance scores

def lccv_evaluator(learner_inst, anchor, timeout, base_scoring, additional_scorings):
    """Calculate extrapolation using the formula shown in the figure."""
    params = learner_inst.get_params()
    selected_params = (params['metric'], params['n_neighbors'], params['weights'], params['p'])

    evaluation_result = custom_evaluator(selected_params + (anchor,))
    if not evaluation_result:
        raise ValueError(f"No valid data for combination: {selected_params} at anchor {anchor}")

    evaluation_result["extrapolated_score"] = evaluation_result["score_test_dummy"]
    return evaluation_result

lccv_predictions = []
surrogate_predictions = []

# Objective function
def objective(trial):
    params = trial.suggest_categorical('params', valid_combinations)
    metric, n_neighbors, weights, p, anchor_size = params

    # Initialize the KNeighborsClassifier learner
    learner_inst = KNeighborsClassifier(
        metric=metric,
        n_neighbors=n_neighbors,
        weights=weights,
        p=p
    )
    configuration = {
        "metric": metric,
        "n_neighbors": n_neighbors,
        "weights": weights,
        "p": p
    }
    best_so_far = None  # No best performance initially
    r = 0.8
    '''For the early stopping threshold (r), we set r=0.9 for config-performances dataset-11 and config-performances dataset-1457, 
    as it balances computational efficiency and the quality of model selection.
    For config-performances dataset-6, we set r=0.8 because it has more anchor points, 
    and using a lower threshold can save computational resources.'''
    base_scoring = ("dummy", lambda l, x, y: None)
    print(f"Evaluating: {learner_inst} with initial anchor_size={anchor_size}")

    # Evaluate the model using the LCCV class
    try:
        lccv_predictions = lccv_instance.evaluate_model(learner_inst=learner_inst, 
                                                        evaluator=lccv_evaluator,
                                                        best_so_far=best_so_far,
                                                        configuration=configuration,
                                                        r=r)
        print("lccv_predictions:{}".format(lccv_predictions))
        surrogate_predictions = []

        # Predict using the surrogate model
        for anchor in anchors:
            surrogate_prediction = Model.predict({
                "metric": metric,
                "n_neighbors": n_neighbors,
                "weights": weights,
                "p": p,
                "anchor_size": anchor
            })
            surrogate_predictions.append((anchor, surrogate_prediction))
            # Evaluate the current anchor using LCCV
            lccv_result = lccv_evaluator(learner_inst=learner_inst,
                                         anchor=anchor, timeout=None,
                                         base_scoring=base_scoring, additional_scorings=None)

            # Extract the actual score from lccv_result
            actual_performance = []
            actual_score = lccv_result["score_test_dummy"]
            actual_performance.append(actual_score)

    except ValueError as e:
        print(f"Error in LCCV evaluation: {e}")
        return float("inf")
    actual_performance.append(actual_score)
    trial.set_user_attr("lccv_predictions", lccv_predictions)
    trial.set_user_attr("surrogate_predictions", surrogate_predictions)
    trial.set_user_attr("actual_performance", actual_performance)

    return -max(actual_performance)

# Run Optuna optimization
study = optuna.create_study(direction="minimize")
study.optimize(objective, n_trials=20)

print(f"Best parameters: {study.best_params['params']}")
print(f"Best score: {-study.best_value}")

'''Compute the differences between LCCV predictions, surrogate model predictions, and true values'''
best_trial = study.best_trial

lccv_predictions = best_trial.user_attrs["lccv_predictions"]
surrogate_predictions = best_trial.user_attrs["surrogate_predictions"]
actual_performance = best_trial.user_attrs["actual_performance"]

print("LCCV Predictions:", lccv_predictions)
print("Surrogate Predictions:", surrogate_predictions)
print("Actual Performance:", actual_performance)

# Group surrogate model predictions by anchor size
grouped_scores = defaultdict(list)
grouped_scores2 = defaultdict(list)
for key, value in surrogate_predictions:
    grouped_scores[key].append(value)
averages_sur = {key: round(sum(values) / len(values), 5) for key, values in grouped_scores.items()}
print(averages_sur)  # Surrogate model predictions

for key, value in lccv_predictions:
    grouped_scores2[key].append(value)
averages_lccv = {key: round(sum(values) / len(values), 5) for key, values in grouped_scores2.items()}
print(averages_lccv)  # LCCV predictions

# True values
true_scores = data.groupby('anchor_size')['score'].mean().sort_index()
true_scores_dict = true_scores.to_dict()

mse_per_anchor_lccv = {}
mse_per_anchor_sur = {}

for anchor in true_scores_dict.keys():
    if anchor in averages_lccv: 
        true_value = true_scores_dict[anchor]
        predicted_value = averages_lccv[anchor]
        mse_lccv = (true_value - predicted_value) ** 2
        mse_per_anchor_lccv[anchor] = mse_lccv

for anchor in true_scores_dict.keys():
    if anchor in averages_sur: 
        true_value = true_scores_dict[anchor]
        predicted_value = averages_sur[anchor]
        mse_sur = (true_value - predicted_value) ** 2
        mse_per_anchor_sur[anchor] = mse_sur
        
mse_df_lccv = pd.DataFrame(list(mse_per_anchor_lccv.items()), columns=["Anchor Size", "MSE"])
mse_df_sur = pd.DataFrame(list(mse_per_anchor_sur.items()), columns=["Anchor Size", "MSE"])
print(mse_df_lccv)
print(mse_df_sur)

plt.figure(figsize=(10, 6))
plt.plot(mse_df_lccv["Anchor Size"], mse_df_lccv["MSE"], marker="o", label="MSE per Anchor (lccv)")
plt.plot(mse_df_sur["Anchor Size"], mse_df_sur["MSE"], marker="o", label="MSE per Anchor (surrogate model)")
plt.xlabel("Anchor Size", fontsize=18)
plt.ylabel("MSE", fontsize=18)
plt.title("MSE for Each Anchor Size", fontsize=24)
plt.grid()
plt.legend()
plt.show()
