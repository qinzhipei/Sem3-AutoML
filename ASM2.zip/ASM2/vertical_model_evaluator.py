from abc import ABC
import ConfigSpace
import numpy as np
import scipy
from surrogate_model import SurrogateModel
from sklearn.pipeline import Pipeline
from scipy.optimize import curve_fit
import typing

class VerticalModelEvaluator(ABC):
    def __init__(self, surrogate_model: Pipeline, minimal_anchor: int, final_anchor: int) -> None:
        self.surrogate_model = surrogate_model
        self.minimal_anchor = minimal_anchor
        self.final_anchor = final_anchor
    
    @staticmethod
    def inverse_power_law_calculation(x, alpha, beta, gamma) -> int:
        return alpha + beta*(x**-gamma) # µˆs = α + βs^−γ


    def evaluate_model(self, best_so_far: float, configuration: typing.Dict) -> typing.List[float]:
        mean_value_curve  = []
        predicted_performance = []
        learning_curve_values = [16, 32, 64, 128, 256]
        gamma_value = 0.5
        for value in learning_curve_values:            
            configuration['anchor_size'] = value
            model_performance = self.surrogate_model.predict(configuration)
            ipl_value_direct = self.inverse_power_law_calculation(model_performance,self.minimal_anchor,self.final_anchor,gamma_value)
            predicted_performance.append(model_performance)

        population,_ = curve_fit(self.inverse_power_law_calculation, learning_curve_values, predicted_performance,maxfev=10000)
        alpha, beta, gamma = population
        # ipl_value = self.inverse_power_law_calculation(value, alpha, beta, gamma)
        # mean_value_curve.append(ipl_value)
        # result = (predicted_performance,mean_value_curve)
        # results.append(result)
        # return results
        for value in learning_curve_values:
            ipl_value = self.inverse_power_law_calculation(value, alpha, beta, gamma)
            # print("Acutal IPL Value {}".format(ipl_value_direct))
            # print("Predicted IPL Value is {}".format(ipl_value))
            if best_so_far is None or best_so_far < ipl_value:
                best_so_far = ipl_value
            mean_value_curve.append(best_so_far)
        return predicted_performance, mean_value_curve