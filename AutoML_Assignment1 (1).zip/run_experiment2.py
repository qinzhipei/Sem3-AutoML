import argparse
import ConfigSpace
import matplotlib.pyplot as plt

import pandas as pd
import numpy as np
from random_search import RandomSearch
from surrogate_model import SurrogateModel
from smbo import SequentialModelBasedOptimization
from successive_halving import SuccessiveHalvingModel
from GridSearch import knn_classification  
from sklearn.metrics import accuracy_score, mean_squared_error
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.neighbors import KNeighborsRegressor,KNeighborsClassifier

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config_space_file', type=str, default='lcdb_config_space_knn.json')
    parser.add_argument('--configurations_performance_file', type=str, default='config_performances_dataset-1457.csv')
    parser.add_argument('--max_anchor_size', type=int, default=1600)
    parser.add_argument('--num_iterations', type=int, default=1000)
    return parser.parse_args()

def run_grid_search_knn(X_train, y_train, X_valid, y_valid, target_type='continuous'):
    if target_type == 'continuous':
        # Use KNeighborsRegressor for regression tasks
        param_grid = {'n_neighbors': [3, 5, 7, 9, 11, 15], 'weights': ['uniform', 'distance']}
        knn = KNeighborsClassifier()
        grid_search = GridSearchCV(knn, param_grid, cv=1, scoring='neg_mean_squared_error')
        grid_search.fit(X_train, y_train)
        best_score = -grid_search.best_score_
        best_params = grid_search.best_params_
        print(f"Best Grid Search (KNN Regressor) Params: {best_params}, MSE: {best_score}")
        return best_score
    else:
        return knn_classification(X_train, y_train, X_valid, y_valid)

def run_experiment(args):
    config_space = ConfigSpace.ConfigurationSpace.from_json(args.config_space_file)
    df = pd.read_csv(args.configurations_performance_file)
    X = df.drop(columns=['score'])
    y = df['score']
    
    # Determine target type: continuous for regression or categorical for classification
    target_type = 'continuous' if y.dtype.kind in 'fc' else 'categorical'
    
    X_train, X_valid, y_train, y_valid = train_test_split(pd.get_dummies(X, drop_first=True), y, test_size=0.2, random_state=42)

    # Run Grid Search
    grid_search_score = run_grid_search_knn(X_train, y_train, X_valid, y_valid, target_type=target_type)

    # Run Random Search
    random_search = RandomSearch(config_space)
    surrogate_model = SurrogateModel(config_space)
    surrogate_model.fit(df)
    random_search_results = [1.0]

    for idx in range(args.num_iterations):
        theta_new = dict(random_search.select_configuration())
        theta_new['anchor_size'] = args.max_anchor_size
        performance = surrogate_model.predict(theta_new)
        random_search_results.append(min(random_search_results[-1], performance))
        random_search.update_runs((theta_new, performance))

    # Run SMBO
    smbo_model = SequentialModelBasedOptimization(config_space)
    capital_phi = [(np.array(row[:-1]), row[-1]) for row in df.values]
    smbo_model.initialize(capital_phi)
    smbo_results = []

    for idx in range(args.num_iterations):
        theta_new = dict(random_search.select_configuration())
        theta_new['anchor_size'] = args.max_anchor_size
        capital_theta, expected_improvement = smbo_model.select_configuration(theta_new)
        smbo_results.append(expected_improvement)

    plt.figure(figsize=(10, 6))
    plt.plot(range(len(random_search_results)), random_search_results, label="Random Search",color='orange')
    plt.plot(range(len(smbo_results)), smbo_results, label="SMBO", color='green')
    plt.axhline(y=grid_search_score, color='blue', linestyle='--', label="Grid Search KNN")
    plt.xlabel("Timesteps",fontsize=16)
    plt.ylabel("Accuracy",fontsize=16)
    plt.legend()
    plt.title("Performance Comparison: Grid Search KNN, Random Search, SMBO",fontsize=20)
    plt.show()

if __name__ == "__main__":
    args = parse_args()
    run(args)
