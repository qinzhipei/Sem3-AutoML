import numpy as np
import sklearn.gaussian_process
import sklearn.gaussian_process.kernels
import typing
import pandas as pd
from sklearn.pipeline import Pipeline

from scipy.stats import norm

import sklearn.impute as impute
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler

#Gaussian process regression model hyperparameter optimization
class SequentialModelBasedOptimization:
    def __init__(self,config_space):
        self.model = sklearn.gaussian_process.GaussianProcessRegressor(
            kernel=sklearn.gaussian_process.kernels.Matern(), random_state=1) 
        self.capital_r = [] 
        self.theta_inc_performance = None
        self.theta_inc = None
        self.df = None
        self.config_space = config_space
        self.model_pipeline = None

    def initialize(self, capital_phi: typing.List[typing.Tuple[np.array, float]]) -> None:
        self.capital_r = capital_phi
        default_columns = [hyperparameter.name for hyperparameter in self.config_space.get_hyperparameters()]
        default_columns.append('anchor_size')
        configurations = pd.DataFrame([theta[0] for theta in self.capital_r], columns=default_columns)
        performances = np.array([theta[1] for theta in self.capital_r])
        self.df = configurations
        self.fit_model()
        for configuration, performance in capital_phi:
            if self.theta_inc_performance is None or performance > self.theta_inc_performance:
                self.theta_inc = configuration
                self.theta_inc_performance = performance
        self.model_pipeline.fit(configurations, performances)

    def fit_model(self) -> None:
        object_columns = self.df.select_dtypes(['object']).columns
        numerical_columns = self.df.select_dtypes(['int64', 'float64']).columns

        number_pipeline = Pipeline(steps=[('imputer', impute.SimpleImputer(strategy='mean')), ('scaler', StandardScaler())])
        text_pipeline = Pipeline(steps=[('categorical_encoder', OneHotEncoder(handle_unknown='ignore'))])

        preprocess_dataframe = ColumnTransformer(transformers=[("number_values", number_pipeline, numerical_columns),("text_values", text_pipeline, object_columns)])
        data_pipeline = Pipeline(steps=[("preprocessor", preprocess_dataframe), ("model", self.model)])
        self.model_pipeline = data_pipeline

    def select_configuration(self, capital_theta: dict) -> np.array:   
        capital_theta_dataframe = pd.DataFrame([capital_theta])
        default_values = {hyperparameter.name: hyperparameter.default_value for hyperparameter in self.config_space.get_hyperparameters()}
        for col in default_values.keys():
            if col not in capital_theta_dataframe.columns:
                capital_theta_dataframe[col] = default_values[col]

        capital_theta_df = capital_theta_dataframe.reset_index(drop=True)
        theta_array = capital_theta_dataframe.reset_index(drop=True).to_numpy()
        ei = self.expected_improvement(self.model_pipeline, self.theta_inc_performance, capital_theta_df)
        best = np.where(ei == np.max(ei))[0]
        ei_star = np.random.choice(best)
        selected_configuration = capital_theta_dataframe.iloc[ei_star].to_dict()
        return selected_configuration, ei

    @staticmethod
    def expected_improvement(model_pipeline: Pipeline,f_star: float, theta: np.array) -> np.array:
        n,m = theta.shape
        mean,std = model_pipeline.predict(theta,return_std=True)
        EI = (mean - f_star) * norm.cdf((mean - f_star)/std) + std * (norm.pdf((mean - f_star)/std))
        return EI

    def update_runs(self, run: typing.Tuple[typing.Dict, float]):
        self.capital_r.append(run)
        configuration, performance = run
        if self.theta_inc_performance is None or performance > self.theta_inc_performance:
            self.theta_inc = configuration
            self.theta_inc_performance = performance
