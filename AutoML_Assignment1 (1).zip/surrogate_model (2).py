import ConfigSpace

import ConfigSpace.hyperparameters
import sklearn.impute as impute
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error as mse, r2_score as r2
from sklearn.pipeline import Pipeline
import pandas as pd

from scipy.stats import spearmanr
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import StandardScaler
from sklearn.compose import ColumnTransformer

class SurrogateModel:

    def __init__(self, config_space):
        self.config_space = config_space
        self.df = None
        self.model = RandomForestRegressor()
        self.feature_columns = None
        self.spearman_correlation = None
        self.p_value = None
        self.mean_score = None
        self.r2_score = None
        self.data_pipeline = None

    def fit(self, df):

        X = df.drop(columns='score')
        y = df['score']

        object_columns = X.select_dtypes(['object']).columns
        numerical_columns = X.select_dtypes(['int64', 'float64']).columns

        number_pipeline = Pipeline(steps=[('imputer',impute.SimpleImputer(strategy='mean')),('scaler',StandardScaler())])
        text_pipeline = Pipeline(steps=[('categorical_encoder',OneHotEncoder(handle_unknown='ignore'))])

        preprocess_dataframe = ColumnTransformer(transformers=[("number_values",number_pipeline,numerical_columns),
                                                 ("text_values",text_pipeline,object_columns)])
        
        x_train, x_test, y_train, y_test = train_test_split(X,y, test_size=0.25, random_state=40)
        data_pipeline = Pipeline(steps=[("preprocessor",preprocess_dataframe),("model",self.model)])
        data_pipeline.fit(x_train, y_train)
        self.feature_columns = list(data_pipeline.named_steps['preprocessor'].get_feature_names_out())
        self.data_pipeline = data_pipeline

        
        x_trained_for_correlation = pd.DataFrame(data_pipeline.named_steps['preprocessor'].transform(x_train),columns=self.feature_columns)
        spearman_corr, p_values = [], []
        for column_name in x_trained_for_correlation.columns:
            if x_trained_for_correlation[column_name].nunique() > 1: 
                spearman_corr_value, p_value = spearmanr(x_trained_for_correlation[column_name], y_train)
                spearman_corr.append(spearman_corr_value)
                p_values.append(p_value)
            else:
                spearman_corr.append(0)
                p_values.append(0)

        self.spearman_correlation = pd.DataFrame(spearman_corr, index=self.feature_columns, columns = ['Value'])
        self.p_value = pd.DataFrame(p_values, index=self.feature_columns, columns = ['Value'])

        predicted_model_output = data_pipeline.predict(x_test)
        self.mean_score = mse(y_test, predicted_model_output)
        self.r2_score = r2(y_test, predicted_model_output)

    def predict(self, theta_new):
        theta_new = pd.DataFrame([theta_new])
        default_values = {hyperparameter.name: hyperparameter.default_value for hyperparameter in self.config_space.get_hyperparameters()}
        for col in default_values.keys():
            if col not in theta_new.columns:
                theta_new[col] = default_values[col]
        theta_new.reset_index(drop=True)
        predicted_theta_new = self.data_pipeline.predict(theta_new)
        
        return predicted_theta_new.item()


    def metrics(self):
        return self.spearman_correlation, self.p_value, self.mean_score, self.r2_score