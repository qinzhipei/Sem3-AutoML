import numpy as np
import pandas as pd
import ConfigSpace
import sklearn.impute as impute
import matplotlib.pyplot as plt

from sklearn.neighbors import KNeighborsRegressor
from sklearn.pipeline import Pipeline
from sklearn.experimental import enable_halving_search_cv  
from sklearn.model_selection import HalvingRandomSearchCV
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import OneHotEncoder

class SuccessiveHalvingModel(object):
        def __init__(self) -> None:
                self.config_space = ConfigSpace.ConfigurationSpace.from_json('lcdb_config_space_knn.json')
                self.arm_count = 25
                self.halving_rate = 2
                self.model = KNeighborsRegressor()
                self.dataframe = pd.read_csv("lcdb_configs.csv")
                self.theta_values = None
                self.performance = None
                self.trained_model = None
        
        def train_model(self):
 
                self.theta_values = self.dataframe.drop(columns=['score'])
                self.performance = self.dataframe['score'].to_numpy()
                object_columns = self.dataframe.select_dtypes(['object']).columns.to_list()
                numerical_columns = self.dataframe.select_dtypes(['int64', 'float64']).columns.to_list()
                numerical_columns.remove('score')

                number_pipeline = Pipeline(steps=[('imputer', impute.SimpleImputer(strategy='mean')), ('scaler', StandardScaler())])
                text_pipeline = Pipeline(steps=[('categorical_encoder', OneHotEncoder(handle_unknown='ignore'))])

                preprocess_dataframe = ColumnTransformer(transformers=[("number_values", number_pipeline, numerical_columns),("text_values", text_pipeline, object_columns)])
                data_pipeline = Pipeline(steps=[("preprocessor", preprocess_dataframe), ("model", self.model)])

                self.trained_model = data_pipeline.fit(self.theta_values, self.performance)
        
        def halving_model(self):
                param_distributions = {}
                self.train_model()
                default_columns = [hyperparameter.name for hyperparameter in self.config_space.get_hyperparameters()]
                for name in default_columns:
                        if name == 'weights' or name == 'metric':
                                param_distributions.update({f"model__{hyperparameter.name}":list(hyperparameter.choices) for hyperparameter in self.config_space.get_hyperparameters() if hyperparameter.name == name})
                        elif name == 'n_neighbors' or name == 'p':
                                param_distributions.update({f"model__{hyperparameter.name}": range(hyperparameter.lower, hyperparameter.upper) for hyperparameter in self.config_space.get_hyperparameters() if hyperparameter.name == name})
                        else:
                                pass
                max_neighbors = min(self.arm_count, len(self.performance) - 1)  
                param_distributions.update({f"model__n_neighbors": range(1, max_neighbors + 1) })

                halving_model = HalvingRandomSearchCV(self.trained_model,
                                                param_distributions=param_distributions,
                                                max_resources=self.arm_count, 
                                                factor=self.halving_rate, random_state=2094)

                halving_model.fit(self.theta_values,self.performance)
                best_values = halving_model.best_params_
                cv_frame = halving_model.cv_results_
                mean_test_scores = list(cv_frame['mean_test_score'])
                n_neighbors = list(cv_frame['param_model__n_neighbors'])
                weights = list(cv_frame['param_model__metric'])
                p_values = list(cv_frame['param_model__p'])

                plt.figure(figsize=(10, 6))
                plt.plot(mean_test_scores,n_neighbors, 'o-')
                plt.plot(mean_test_scores,weights, 'o-')
                plt.plot(mean_test_scores,weights, 'o-')
                # plt.plot(weights, mean_test_scores, 'o-')
                # plt.plot(p_values, mean_test_scores, 'o-')
                plt.title('Successive Halving Results')
                plt.xlabel('Number of Estimators')
                plt.ylabel('Mean Test Score')
                plt.grid(True)
                #plt.show()
                plt.savefig("successive_halving.png")
                return best_values

if __name__ == '__main__':
        successive_halving = SuccessiveHalvingModel()
        best_values = successive_halving.halving_model()
        print(best_values)