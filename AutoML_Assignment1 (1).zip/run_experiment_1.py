import argparse
import ConfigSpace
import matplotlib.pyplot as plt

import pandas as pd
import numpy as np
from random_search import RandomSearch
from surrogate_model import SurrogateModel

from matplotlib.sankey import Sankey
from smbo import SequentialModelBasedOptimization
from successive_halving import SuccessiveHalvingModel

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config_space_file', type=str, default='lcdb_config_space_knn.json')
    # parser.add_argument('--configurations_performance_file', type=str, default='lcdb_configs.csv')
    # parser.add_argument('--configurations_performance_file', type=str, default='config_performances_dataset-6.csv')
    # parser.add_argument('--configurations_performance_file', type=str, default='config_performances_dataset-11.csv')
    parser.add_argument('--configurations_performance_file', type=str, default='config_performances_dataset-1457.csv')
    # max_anchor_size: connected to the configurations_performance_file. The max value upon which anchors are sampled
    parser.add_argument('--max_anchor_size', type=int, default=1600)
    parser.add_argument('--num_iterations', type=int, default=500)
    return parser.parse_args()

def run_surrogate_model(args):
    config_space = ConfigSpace.ConfigurationSpace.from_json(args.config_space_file)
    random_search = RandomSearch(config_space)
    df = pd.read_csv(args.configurations_performance_file)
    surrogate_model = SurrogateModel(config_space)
    surrogate_model.fit(df)
    results = {'random_search': [1.0]}

    dataset_scores = pd.DataFrame(columns=["Dataset","MSE_Score","r2_score"])
    for idx in range(args.num_iterations):
        theta_new = dict(random_search.select_configuration())
        theta_new['anchor_size'] = args.max_anchor_size
        performance = surrogate_model.predict(theta_new)
        results['random_search'].append(min(results['random_search'][-1], performance)) # ensure to only record improvements
        random_search.update_runs((theta_new, performance))
    plt.plot(range(len(results['random_search'])), results['random_search'])
    plt.yscale('log')
    plt.xlabel("Runs")
    plt.ylabel("Score")
    plt.title("Performance of Surrogate Model and Random Search of Dataset {}".format(1))
    plt.savefig("surrogate_model_vs_random_search_{}.png".format(1))
    #plt.show()
    
    spearman_correlation, p_value, mean_score, r2_score = surrogate_model.metrics()
    new_row = pd.DataFrame({'Dataset': [4], 'MSE_Score': [mean_score], 'r2_score': [r2_score]})
    dataset_scores = pd.concat([dataset_scores, new_row], ignore_index=True)
    #print("The MSE value of the Model is: {}". format(mean_score))
    #print("The R2 score of the Model is : {}".format(r2_score))
    print(dataset_scores)
    plt.figure(figsize=(8,6))
    plt.hist(spearman_correlation['Value'],label="Spearman Correlation")
    plt.hist(p_value['Value'],label="p-value")
    plt.legend()
    # plt.xticks(rotation=55)
    plt.title("Spearman Correlation and p-value of Dataset {} ".format(1))
    plt.xlabel("Categories")
    plt.ylabel("Values")
    plt.savefig("spearman_and_p-value_{}.png".format(1))

if __name__ == '__main__':
    run_surrogate_model(parse_args())