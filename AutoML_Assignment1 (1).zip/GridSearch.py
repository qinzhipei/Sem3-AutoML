# -*- coding: utf-8 -*-
"""
Created on Thu Oct 26 20:35:57 2023

@author: admin
"""
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
import pandas as pd
from sklearn.model_selection import GridSearchCV
import sklearn.svm
performance_data = pd.read_csv('lcdb_configs.csv')
X = performance_data.drop(columns=['score'])
X_encoded = pd.get_dummies(X, drop_first=True)
y = performance_data['score']

X_train, X_test, y_train, y_test = sklearn.model_selection.train_test_split(X_encoded, y, test_size=0.33, random_state=1)
X_train = sklearn.preprocessing.scale(X_train)
X_test = sklearn.preprocessing.scale(X_test)


import numpy as np
import matplotlib.pyplot as plt

param_grid = {
    'n_neighbors': [3, 5, 7, 9, 11, 15],
    'weights': ['uniform', 'distance'],
    'metric': ['euclidean', 'manhattan', 'minkowski']
}

def knn_classification(X_train, y_train, X_test, y_test):
    knn = KNeighborsClassifier()
    
    grid_search = GridSearchCV(knn, param_grid, cv=5, scoring='accuracy')
    grid_search.fit(X_train, y_train)
    
    best_params = grid_search.best_params_
    best_accuracy = grid_search.best_score_
    print("best parameter：", best_params)
    print("best accuracy：", best_accuracy)
    
    best_knn = KNeighborsClassifier(n_neighbors=best_params['n_neighbors'],
                                    weights=best_params['weights'],
                                    metric=best_params['metric'])
    best_knn.fit(X_train, y_train)
    
    accuracy = accuracy_score(y_test, best_knn.predict(X_test))
    print("accuracy ：", accuracy)

knn_classification(X_train, y_train, X_test, y_test)

